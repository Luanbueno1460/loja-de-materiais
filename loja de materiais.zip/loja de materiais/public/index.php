<?php
session_start();
include '../app/views/home.php';

