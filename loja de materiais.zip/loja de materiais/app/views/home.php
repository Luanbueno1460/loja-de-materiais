<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Loja de Materiais</title>
    <link rel="stylesheet" href="../public/styles.css">
</head>
<body>
    <h1>Bem-vindo à Loja de Materiais</h1>
    <footer>
        <a href="https://github.com/pedrohgrocha">Portfólio Pedro Henrique Gomes Rocha</a> <br>
        <a href="https://github.com/Arthursilveir4">Portfólio Arthur Cardoso Silveira</a> <br>
        <a href="https://github.com/Luanbueno1460">Portfólio Luan de Souza Bueno</a> <br>
    </footer>
</body>
</html>
